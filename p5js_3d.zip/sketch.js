let x
let y
let z
let xs
let ys
let zs
let shape
function setup() {
  shape = createSlider(0,2)
  xs = createSlider(-200,200,0)
  ys = createSlider(-200,200,0)
  zs = createSlider(200,400,0)
  createCanvas(400, 400);
}

function draw() {
  if(shape.value()==0){
  x=[100,300,300,100,100,300,300,100,100,100,100,100,300,300,300,300]
  y=[100,100,100,100,300,300,300,300,300,300,100,100,100,300,300,100]
  z=[100,100,300,300,300,300,100,100,300,100,100,300,300,300,100,100]  
  }
  if(shape.value()==1){
    x=[100,200,300,200,100,300,200,200]
    y=[300,300,300,100,300,300,300,100]
    z=[100,300,100,200,100,100,300,200]
  }
  if(shape.value()==2){
    x=[100]
    y=[80]
    z=[]
    for(let n=0;n<10;n++){
      x.push(x[n]+20)
      if(y[n]==80){
        y.push(120)
      }
      else{
        y.push(80)
      }
    z.push(x[n]/y[n]*100)
    }
  }
  background(220);
    for(n=0;x.length>n;n++){
      line((x[n]+xs.value()+200*400/(z[n]+zs.value()))/(1+400/(z[n]+zs.value())),
           (y[n]+ys.value()+200*400/(z[n]+zs.value()))/(1+400/(z[n]+zs.value())),
           (x[n-1]+xs.value()+200*400/(z[n-1]+zs.value()))/(1+400/(z[n-1]+zs.value())),
           (y[n-1]+ys.value()+200*400/(z[n-1]+zs.value()))/(1+400/(z[n-1]+zs.value())))
  }
}